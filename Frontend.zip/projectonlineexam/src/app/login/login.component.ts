import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/Models/user';
import { LoginserviceService } from '../services/loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  studentForm: FormGroup;
  studentid:number;
  password_user:string="";
  flag:boolean;
  user_email: any;
  constructor(public service: LoginserviceService, public router: Router) {
     
    this.studentForm = new FormGroup({
      
    userEmail:new FormControl('',[Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]),
      
      password: new FormControl('', Validators.compose([
	 	   Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$'),
	 	 
	])),
      
 
   }
   
   //,{validators:any [this.checkPasswords, this.checkAge]},
    );
    console.log("login"); 
  }
  

  ngOnInit(): void {
  }

  s:string;

  SutudentSubmit():void {
    console.log(this.studentForm.get("password")?.value);
    console.log(this.studentForm.get("userEmail")?.value);
    console.log("hello");
    this.password_user=this.studentForm.get("password")?.value;
    this.user_email=this.studentForm.get("userEmail")?.value;
    /*this.service.getbyemail(this.studentForm.get("emailid")?.value).subscribe((data:User)=>{
      console.log(data);
      this.studentid=data.userid;
      console.log(data.state);
      console.log(this.studentid);
    if(this.password_user==data.password){
        console.log("logged in");
        this.flag=(this.flag);
       localStorage.setItem("Userid",this.studentid.toString());
        this.router.navigateByUrl("/studentdashboard");
      }
      else{
        console.log("password mismatch");
      }
    });*/

    this.service.getloginstatus(this.studentForm.value).subscribe((data)=>{
      console.log(data);
      if(this.user_email==data.email && data.status=="Y"){
        console.log("logged in");
        this.flag=true;
        this.studentid=data.userId;
        localStorage.setItem("Userid",this.studentid.toString());
        this.router.navigateByUrl("/studentdashboard");
      }
      else{
        console.log("user not found");
        this.flag=false;
      }
    })
}
reset(){
  this.router.navigateByUrl("/resetpassword");
}
}
function studentId(studentId: any) {
  throw new Error('Function not implemented.');
}

