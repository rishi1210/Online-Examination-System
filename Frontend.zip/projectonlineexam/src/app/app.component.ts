import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'projectonlineexam';


// flag:boolean=false;
//   logout(){
//     console.log("in log out");
// console.log(localStorage.getItem('Userid')?.toString().length);
//     // if(localStorage.getItem('Userid')?.toString().length!=0)
//     // {
//     //  this.flag=true;
//     // }
//     // else{
//     //   this.flag=false;
//     // }
//     localStorage.removeItem('examSpec');
//     localStorage.removeItem('examLevel');
//     localStorage.removeItem('Marks');
//     localStorage.removeItem('Userid');
//     localStorage.removeItem('FullName');
//     localStorage.removeItem('ExamName');
//     localStorage.removeItem('ExamLevel');
//     localStorage.removeItem('Status');
//     this.router.navigateByUrl("/home");
//   }
}
