import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  delete(){
    console.log("delete working");
    this.router.navigateByUrl("/delete");
  }
Search(){
console.log("inside search component");
this.router.navigateByUrl("/search");
}

addquestions(){
 this.router.navigateByUrl("/addquestions");
}

logout(){
  this.router.navigateByUrl("/adminlogin");
}


}
