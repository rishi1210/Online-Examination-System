import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchStudentDto } from 'src/Models/SearchStudentDto';
import { UserInfoDto } from 'src/Models/UserInfoDto';
import { SearchService } from '../services/search.service';

@Component({
  selector: 'app-searchstudent',
  templateUrl: './searchstudent.component.html',
  styleUrls: ['./searchstudent.component.css']
})
export class SearchstudentComponent implements OnInit {

  constructor(private service:SearchService, private router:Router) { }

  searchStudentDto : SearchStudentDto = new SearchStudentDto();

  studentsInfo: UserInfoDto[]=[];
  
  states = ["ANDHRA PRADESH","TELANGANA","TAMIL NADU","MAHARASHTRA","KARNATAKA","GUJARAT","UTTAR PRADESH","PUNJAB","BIHAR","KERALA"]

  cities = ["VIZAG","HYDERABAD","CHENNAI","MUMBAI","BANGALORE","BARODA", "LUCKNOW","CHANDIGARH","PATNA","TRIVANDRUM"]

  exams = ["JAVA","PYTHON","SQL","PHP","C#/.NET","C/C++"];

  levels = ["LEVEL1","LEVEL2","LEVEL3"];

  marks = [10,9,8,7,6,5,4,3,2,1];
 flag:boolean=false;
 flag1:boolean;
length1:number;
searchStudent(){
  this.service.search(this.searchStudentDto).subscribe((data)=>{
  console.log(data);
  this.studentsInfo=data;
   console.log(this.studentsInfo);
   this.flag=true;
   console.log(typeof(this.studentsInfo.length));
   this.length1=this.studentsInfo.length;
   console.log(this.length1);
   
  })
  console.log(this.flag);
  if(this.flag!=true){
    //alert("not found");
   // this.flag1=true;
    console.log(this.flag1);
  }
 
}
  ngOnInit(): void {
    
  }
  logout(){
  this.router.navigateByUrl("/adminlogin");
  }
}
