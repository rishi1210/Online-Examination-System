import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-studentdashboard',
  templateUrl: './studentdashboard.component.html',
  styleUrls: ['./studentdashboard.component.css']
})
export class StudentdashboardComponent implements OnInit {

  constructor(private router:Router) { }
  examSpec : string;
  examLevel : string;
  ngOnInit(): void {
  }


  selectedExam(){
 console.log("selected exam");
 localStorage.setItem("examSpec",this.examSpec);
    localStorage.setItem("examLevel",this.examLevel);

 this.router.navigateByUrl("/exampage");
  }

  logout(){
    console.log("log out");
    localStorage.removeItem('examSpec');
        localStorage.removeItem('examLevel');
       localStorage.removeItem('Marks');
         localStorage.removeItem('Userid');
        localStorage.removeItem('FullName');
         localStorage.removeItem('ExamName');
         localStorage.removeItem('ExamLevel');
         localStorage.removeItem('Status');
        this.router.navigateByUrl("/home");
       }

  
}
