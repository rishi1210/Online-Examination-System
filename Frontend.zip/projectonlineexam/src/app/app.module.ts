import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { StudentdashboardComponent } from './studentdashboard/studentdashboard.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { ExampageComponent } from './exampage/exampage.component';
import { ReportCardComponent } from './report-card/report-card.component';
import { DeletequestionsComponent } from './deletequestions/deletequestions.component';
import { SearchstudentComponent } from './searchstudent/searchstudent.component';
import { AddquestionsComponent } from './addquestions/addquestions.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';


//import { StudentdashboaqrdComponent } from './studentdashboaqrd/studentdashboaqrd.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminloginComponent,
    LoginComponent,
    RegisterComponent,
    StudentdashboardComponent,
    AdmindashboardComponent,
    ExampageComponent,
    ReportCardComponent,
    DeletequestionsComponent,
    SearchstudentComponent,
    AddquestionsComponent,
    ResetpasswordComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
   

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
