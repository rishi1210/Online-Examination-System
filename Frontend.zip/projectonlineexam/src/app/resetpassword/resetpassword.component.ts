import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResetPasswordDto } from 'src/Models/ResetPasswordDto';
import { ResetpasswordService } from '../services/resetpassword.service';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  constructor( private service: ResetpasswordService,private router:Router) { }
  resetPasswordDto : ResetPasswordDto = new ResetPasswordDto();
  confirmPassword : string;
  ngOnInit(): void {
  }

  checkpassword(){
    if(this.confirmPassword==this.resetPasswordDto.newPassword){
      this.resetPassword();
    }
    else{
      alert("Password and Confirm Password not matching")
    }
    }
    
  resetPassword() {
   
this.service.resetpassword(this.resetPasswordDto).subscribe((data)=>{
  if(data.status="Y"){
    console.log("password updated");
    alert("Password upddated");
    this.router.navigateByUrl("/login");
  }
  else{
    alert(data.msg);
  }
})
  }
  
}
