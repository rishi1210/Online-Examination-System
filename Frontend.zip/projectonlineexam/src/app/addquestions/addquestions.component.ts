import { Component,  OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AddQuestionDto } from 'src/Models/AddQuestionDto';
import { AddquestionsForExamDto } from 'src/Models/AddQuestionsForExamDto';
import { ExamInformationDto } from 'src/Models/ExamInformationDto';
import { AddquestionsService } from '../services/addquestions.service';

@Component({
  selector: 'app-addquestions',
  templateUrl: './addquestions.component.html',
  styleUrls: ['./addquestions.component.css']
})
export class AddquestionsComponent implements OnInit {

 
  constructor(private service:AddquestionsService, private router:Router) { }
  
  examInformationDto : ExamInformationDto = new ExamInformationDto();

  noOfQuestions : number;

  status : string;

  addQuestionDto1 : AddQuestionDto = new AddQuestionDto();

  i:number=1;

   flag:boolean;

  questionsList :AddQuestionDto []=[];

  addQuestionsForExamDto : AddquestionsForExamDto = new AddquestionsForExamDto();
  ngOnInit(): void {
  }

  addquestionslot(){
    
      this.questionsList.push(this.addQuestionDto1);
      this.flag=true;
    
  }
  addQuestions(){
    console.log(this.addQuestionsForExamDto)
   
    this.service.addquestionsforexam(this.addQuestionsForExamDto).subscribe((data)=>{
     // this.status=JSON.parse("data");
     // if(data!=null){
       // alert("Questions are adde successfully")
      
         
         console.log(data);
      })
    alert("Question added");
  
  }
  
  addQuestionsToExam(){
  
   this.addQuestionsForExamDto.questionsList = this.questionsList;
   this.addQuestionsForExamDto.examLevel = this.examInformationDto.examLevel;
   this.addQuestionsForExamDto.examSpecialization=this.examInformationDto.examSpecialization;
   console.log(this.addQuestionsForExamDto)
   this.addQuestions();
  }

  logout(){
    this.router.navigateByUrl("/adminlogin");
  }
}
