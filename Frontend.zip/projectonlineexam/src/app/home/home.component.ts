import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
flag:boolean;
  constructor(private router:Router) {
    console.log("in log out");
     console.log(localStorage.getItem('Userid')!=null);

        if(localStorage.getItem('Userid')!=null)
         {
           this.flag=false;
          }
         else{
           this.flag=true;
          }
   }

  ngOnInit(): void {
  }
  logout(){
console.log("log out");
    localStorage.removeItem('examSpec');
        localStorage.removeItem('examLevel');
       localStorage.removeItem('Marks');
         localStorage.removeItem('Userid');
        localStorage.removeItem('FullName');
         localStorage.removeItem('ExamName');
         localStorage.removeItem('ExamLevel');
         localStorage.removeItem('Status');
        window.location.reload();
  }
}
