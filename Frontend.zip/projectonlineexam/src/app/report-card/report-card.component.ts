
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReportCardDto } from 'src/Models/ReportCardDto';
import { GetreportcardService } from '../services/getreportcard.service';

@Component({
  selector: 'app-report-card',
  templateUrl: './report-card.component.html',
  styleUrls: ['./report-card.component.css']
})
export class ReportCardComponent implements OnInit {

  userid: any;
  reportCard : ReportCardDto[]=[];
temp:string;

  constructor(private serice : GetreportcardService , private router:Router) { 
    this.examspec=JSON.parse(localStorage.getItem('examSpec') || '{}');
    this.examlevel=JSON.parse(localStorage.getItem('examLevel') || '{}');
    this.marks=JSON.parse(localStorage.getItem('Marks') || '{}');
    this.userid= JSON.parse(localStorage.getItem('Userid') || '{}');
    //this.name=localStorage.getItem('FullName') ;
    //this.status=JSON.parse(localStorage.getItem('Status') || '{}');
    this.serice.getreportcard(this.userid).subscribe((data)=>{
      console.log(data);
    
this.temp=this.examlevel;

console.log(this.temp.toLowerCase());
      for(var i=0;i<data.length;i++){
        this.reportCard.push(data[i]);
      }

      console.log(data.length);
      
      
    })

  }

examspec:string;
examlevel:string;
marks:number;
status:string;
name:string;

onclick(){
  this.router.navigateByUrl("/studentdashboard");
}

  ngOnInit(): void {
    
  }


  logout(){
    console.log("log out");
    localStorage.removeItem('examSpec');
        localStorage.removeItem('examLevel');
       localStorage.removeItem('Marks');
         localStorage.removeItem('Userid');
        localStorage.removeItem('FullName');
         localStorage.removeItem('ExamName');
         localStorage.removeItem('ExamLevel');
         localStorage.removeItem('Status');
        this.router.navigateByUrl("/home");
  }
}
