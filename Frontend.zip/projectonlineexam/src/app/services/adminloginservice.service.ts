import { Injectable } from '@angular/core';
import { Admin } from 'src/Models/admin';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminloginserviceService {

  private ApiUrl="http://localhost:8060/adminlogin";

  constructor(private http: HttpClient) {}
  
 adminlogin(admin:Admin): Observable<Admin>{
  const headers = { 'content-type': 'application/json'} 
  console.log(this.http.post<Admin>(this.ApiUrl, admin));
  return this.http.post<Admin>(this.ApiUrl, admin);
 }
}

