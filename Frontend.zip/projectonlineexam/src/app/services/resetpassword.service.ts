import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Message } from 'src/Models/Message';
import { ResetPasswordDto } from 'src/Models/ResetPasswordDto';

@Injectable({
  providedIn: 'root'
})
export class ResetpasswordService {
BaseUrl="http://localhost:8060/resetpassword";
  constructor(private http: HttpClient) { }

  resetpassword(reset:ResetPasswordDto){
   return  this.http.put<Message>(this.BaseUrl,reset);
  }
}
