import { TestBed } from '@angular/core/testing';

import { DeleteexamService } from './deleteexam.service';

describe('DeleteexamService', () => {
  let service: DeleteexamService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeleteexamService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
