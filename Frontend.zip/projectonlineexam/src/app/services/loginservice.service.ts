import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'src/Models/user';
import { UserInfoDto } from 'src/Models/UserInfoDto';
import { UserLoginDto } from 'src/Models/UserLoginDto';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {
  private emailUrl="http://localhost:8060/GetUsersByEmail";
  constructor(private http: HttpClient) { }

  getbyemail(email: string): Observable<User> {
    console.log("hello in service");
    let url = this.emailUrl +"/" +email;
    console.log(url);
    return this.http.get<User>(url); 
    
  }
private loginUrl="http://localhost:8060/userlogin";

  getloginstatus(login:UserLoginDto){
    console.log(login);
    return this.http.post<UserInfoDto>(this.loginUrl,login);
  }
  

}
