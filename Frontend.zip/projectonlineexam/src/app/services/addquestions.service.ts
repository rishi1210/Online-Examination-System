import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddquestionsForExamDto } from 'src/Models/AddQuestionsForExamDto';

@Injectable({
  providedIn: 'root'
})
export class AddquestionsService {

  constructor(private http: HttpClient) { }
BaseUrl="http://localhost:8060/addquestionsforexam";

  addquestionsforexam(addquestions:AddquestionsForExamDto): Observable<any>{
return this.http.post<any>(this.BaseUrl,addquestions);
  }
}
