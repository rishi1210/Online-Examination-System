import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AddResponsesForExamDto } from 'src/Models/AddResponsesForExamDto';
import { ReportCardDto } from 'src/Models/ReportCardDto';
import { ResponseInfoDto } from 'src/Models/ResponseInfoDto';

@Injectable({
  providedIn: 'root'
})
export class AddresponsesService {

  constructor(private http: HttpClient) { }
BaseUrl="http://localhost:8060/addresponses";
  addresponses(addresponse:AddResponsesForExamDto){
console.log(addresponse);
console.log("I am in response service");
return this.http.post<ReportCardDto>(this.BaseUrl,addresponse);
  }
}
