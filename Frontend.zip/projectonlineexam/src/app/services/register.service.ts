import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'src/Models/user';
import { UserCreate } from 'src/Models/UserCreate';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient) { }
  BaseUrl="http://localhost:8060/registeruser";

RegisterUser(user:UserCreate):Observable<any>{

  console.log("in regsiter service");

  console.log(user);
  console.log(user.dateOfBirth);
  return this.http.post<any>(this.BaseUrl,user);

}

}
