import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportCardDto } from 'src/Models/ReportCardDto';

@Injectable({
  providedIn: 'root'
})
export class GetreportcardService {

  constructor(private http: HttpClient) { }
 BaseUrl="http://localhost:8060/getreportcard";
 
  getreportcard(userid:number){
return this.http.get<ReportCardDto[]>(this.BaseUrl+"/"+userid);
  }
}
