import { TestBed } from '@angular/core/testing';

import { GetquestionsService } from './getquestions.service';

describe('GetquestionsService', () => {
  let service: GetquestionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetquestionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
