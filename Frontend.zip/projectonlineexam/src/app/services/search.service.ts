import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SearchStudentDto } from 'src/Models/SearchStudentDto';
import { UserInfoDto } from 'src/Models/UserInfoDto';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http: HttpClient) { }
BaseUrl="http://localhost:8060/searchstudentsinfo";

  search(searchStudent : SearchStudentDto){
return this.http.post<UserInfoDto[]>(this.BaseUrl,searchStudent);
  }
}
