import { TestBed } from '@angular/core/testing';

import { AddquestionsService } from './addquestions.service';

describe('AddquestionsService', () => {
  let service: AddquestionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddquestionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
