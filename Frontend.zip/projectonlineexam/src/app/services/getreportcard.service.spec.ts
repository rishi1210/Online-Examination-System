import { TestBed } from '@angular/core/testing';

import { GetreportcardService } from './getreportcard.service';

describe('GetreportcardService', () => {
  let service: GetreportcardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetreportcardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
