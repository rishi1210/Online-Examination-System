import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ExamInformationDto } from 'src/Models/ExamInformationDto';
import { QuestionDetailsDto } from 'src/Models/QuestionDetailsDto';

@Injectable({
  providedIn: 'root'
})
export class GetquestionsService {

  constructor(private http: HttpClient) { }
BaseUrl="http://localhost:8060/getquestionsforexam"; 

  getquestions(examInformationDto: ExamInformationDto){
    console.log(examInformationDto);
    return this.http.post<QuestionDetailsDto[]>(this.BaseUrl,examInformationDto);    
  }
}
