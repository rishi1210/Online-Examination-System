import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DeleteQuestionsForExamDto } from 'src/Models/DeleteQuestionsForExamDto';

@Injectable({
  providedIn: 'root'
})
export class DeleteexamService {
  errorMessage: any;

  constructor(private http: HttpClient) { }

BAseUrl="http://localhost:8060/deletequestionsforexam";

deletequestion(deleteQuestionsForExam : DeleteQuestionsForExamDto) : Observable<any> {
   return this.http.post<String>(this.BAseUrl,deleteQuestionsForExam);
  }
}
