import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddquestionsComponent } from './addquestions/addquestions.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { DeletequestionsComponent } from './deletequestions/deletequestions.component';
import { ExampageComponent } from './exampage/exampage.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ReportCardComponent } from './report-card/report-card.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { SearchstudentComponent } from './searchstudent/searchstudent.component';
import { StudentdashboardComponent } from './studentdashboard/studentdashboard.component';

const routes: Routes = [
  {path:"adminlogin",component:AdminloginComponent},
  {path:"login",component:LoginComponent},
  {path:"regsiter",component:RegisterComponent},
  {path:"home",component:HomeComponent},
  {path:"admindashboard",component:AdmindashboardComponent},
  {path:"studentdashboard",component:StudentdashboardComponent},
  {path:"exampage",component:ExampageComponent},
  {path:"reportcard",component: ReportCardComponent},
  {path:"delete",component: DeletequestionsComponent},
  {path:"search",component: SearchstudentComponent},
  {path:"addquestions",component: AddquestionsComponent},
  {path:"resetpassword",component: ResetpasswordComponent},
  {path:"**",component: HomeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
