import { identifierModuleUrl } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddResponsesForExamDto } from 'src/Models/AddResponsesForExamDto';
import { ExamInformationDto } from 'src/Models/ExamInformationDto';
import { ReportCardDto } from 'src/Models/ReportCardDto';
import { ResponseInfoDto } from 'src/Models/ResponseInfoDto';
import { AddresponsesService } from '../services/addresponses.service';
import { GetquestionsService } from '../services/getquestions.service';

@Component({
  selector: 'app-exampage',
  templateUrl: './exampage.component.html',
  styleUrls: ['./exampage.component.css']
})
export class ExampageComponent implements OnInit {
  questionsList : any;
  userid: number;
  i:number=0;
 len:number;
  constructor(private service :GetquestionsService,private responseservice:AddresponsesService,private router:Router) { 
    
   this.examSpec = JSON.parse(localStorage.getItem('examSpec') || '{}');
   console.log(this.examSpec);

  // console.log(this.examSpec.slice(3,7));
    this.examLevel = JSON.parse(localStorage.getItem('examLevel') || '{}');

  //  console.log(this.examLevel.slice(3,9));
    console.log(typeof(localStorage.getItem("examSpec")));
    
    console.log(this.examLevel);
    this.examInformationDto.examLevel = this.examLevel;
    this.examInformationDto.examSpecialization = this.examSpec;
    var i=0;
    this.service.getquestions(this.examInformationDto).subscribe((data)=>{
      this.questionsList=data;
      console.log(data);
      i=data.length;
      this.len=i;
      console.log(i);
      
      for(var j=0;j<i;j++){
        console.log(j);
        this.riDto[j]=new ResponseInfoDto();
        this.responsesList.push(this.riDto[j]);
      }
    })

   this.userid= JSON.parse(localStorage.getItem('Userid') || '{}');


   
   //this.responsesList.push(this.riDto1);
   //this.responsesList.push(this.riDto2);
   //this.responsesList.push(this.riDto3);
   //this.responsesList.push(this.riDto4);
   //this.responsesList.push(this.riDto5);
  //  this.responsesList.push(this.riDto6);
  //  this.responsesList.push(this.riDto7);
  //  this.responsesList.push(this.riDto8);
  //  this.responsesList.push(this.riDto9);
  //  this.responsesList.push(this.riDto10);


 
    }

  examInformationDto : ExamInformationDto = new ExamInformationDto();
  
  addResponsesForExamDto : AddResponsesForExamDto = new AddResponsesForExamDto();

  reportCardDto : ReportCardDto = new ReportCardDto();

  examSpec : string

  examLevel : string;

  responsesList:ResponseInfoDto[]=[];

  riDto : ResponseInfoDto[]=[];
  //riDto2 : ResponseInfoDto = new ResponseInfoDto();
  //riDto3 : ResponseInfoDto = new ResponseInfoDto();
  //riDto4 : ResponseInfoDto = new ResponseInfoDto();
  //riDto5 : ResponseInfoDto = new ResponseInfoDto();
  // riDto6 : ResponseInfoDto = new ResponseInfoDto();
  // riDto7 : ResponseInfoDto = new ResponseInfoDto();
  // riDto8 : ResponseInfoDto = new ResponseInfoDto();
  // riDto9 : ResponseInfoDto = new ResponseInfoDto();
  // riDto10 : ResponseInfoDto = new ResponseInfoDto();

  
        
  addResponsestoList(questionid:number,k:number,answer:string){
    this.responsesList[k].questionId=questionid;
    this.responsesList[k].userId=this.userid;
    this.responsesList[k].response=answer;

  }

  changeresponse(event:any,qid:number,i:number){
    console.log(event.target.value);
    console.log(qid);
    console.log(i);
    this.addResponsestoList(qid,i,event.target.value);
  }

  count():number{
    var temp=0;
    for(var res=0; res <this.responsesList.length;res++){
      if(this.responsesList[res].questionId!=null){
        temp++;
      }
    }
    this.len=temp;
    console.log(temp);
    return temp;
  }
  submitResponses(){
    var j=this.count();
    console.log(j);
    console.log(this.responsesList.length);
    if(j!=this.responsesList.length){
      alert("Enter all the questions");
    }
    else{
    console.log("inside a question");
    console.log(this.responsesList);
    console.log(this.examSpec);
    console.log(this.examLevel);
    this.addResponsesForExamDto.examSpecialization=this.examSpec;
    this.addResponsesForExamDto.examLevel=this.examLevel;
    this.addResponsesForExamDto.responseList=this.responsesList;
    this.responseservice.addresponses(this.addResponsesForExamDto).subscribe((data)=>{
    console.log(data);

    localStorage.setItem("ExamName",data.examSpec);
    localStorage.setItem("ExamLevel",data.examLevel);
    localStorage.setItem("FullName",data.fullName);
    localStorage.setItem("Marks",JSON.stringify(data.marks));
    localStorage.setItem("Status",data.status);
    this.router.navigateByUrl("/reportcard");

})
}
  

  
    }

    ngOnInit(): void {
   
    }

    logout(){
      console.log("log out");
      localStorage.removeItem('examSpec');
          localStorage.removeItem('examLevel');
         localStorage.removeItem('Marks');
           localStorage.removeItem('Userid');
          localStorage.removeItem('FullName');
           localStorage.removeItem('ExamName');
           localStorage.removeItem('ExamLevel');
           localStorage.removeItem('Status');
          this.router.navigateByUrl("/home");
    }
  
}
