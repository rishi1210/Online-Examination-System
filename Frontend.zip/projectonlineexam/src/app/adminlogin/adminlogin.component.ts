import { Component, OnInit } from '@angular/core';
//import { FormGroup } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminloginserviceService } from '../services/adminloginservice.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  AdminForm: FormGroup;
  
  constructor(public service: AdminloginserviceService, public router: Router) { 
    console.log("adminlogin");
    this.AdminForm = new FormGroup({
      adminEmail:new FormControl('',[Validators.required]),
      password: new FormControl('', [Validators.required]),  
   });
    
  }
  get Password() {
    return this.AdminForm.get("Password");
  }
  get Loginid(){
    return this.AdminForm.get("AdminForm");
  }
  ngOnInit(): void {
  }

  Submit(): void{

    console.log(this.AdminForm.get("Password")?.value);
    console.log(this.AdminForm.get("AdminForm")?.value);

   this.service.adminlogin(this.AdminForm.value).subscribe(res => {
    console.log('Logged in'),
    console.log(res)
    console.log(JSON.stringify(res));
    if (res.status=="Y") {
      console.log("logged in");
      this.router.navigate(['/admindashboard']);
    } else if(JSON.stringify(res).includes("Invalid")) {
     console.log("not matched");
    }
   
  });


  }
}
