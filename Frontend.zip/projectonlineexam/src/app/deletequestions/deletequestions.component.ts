import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DeleteQuestionsForExamDto } from 'src/Models/DeleteQuestionsForExamDto';
import { DeleteexamService } from '../services/deleteexam.service';

@Component({
  selector: 'app-deletequestions',
  templateUrl: './deletequestions.component.html',
  styleUrls: ['./deletequestions.component.css']
})
export class DeletequestionsComponent implements OnInit {
  
  deleteQuestionsForExamDto : DeleteQuestionsForExamDto = new DeleteQuestionsForExamDto
  constructor(private service : DeleteexamService , private router:Router) { }

  ngOnInit(): void {
  }
  
  deleteQuestions() : void  {
    alert("deleting questions");
this.service.deletequestion(this.deleteQuestionsForExamDto).subscribe((data)=>{
console.log(data);
});
  }

  logout(){
    this.router.navigateByUrl("/adminlogin");
  }
}
