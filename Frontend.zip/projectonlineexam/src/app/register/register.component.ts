import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/Models/user';
import { UserCreate } from 'src/Models/UserCreate';
import { RegisterService } from '../services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  Registerform: any;

  constructor(private formbuilder: FormBuilder,public service: RegisterService, public router: Router) { 
    this.Registerform = this.formbuilder.group({      
      fullName:['',[Validators.required]],
      email:['',[Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['',[Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]], 

      mobile: ['',[Validators.required, Validators.pattern('^([7-9]{1}[0-9]{9})$')]],
      city: ['',[Validators.required]],
      dateOfBirth: ['',[Validators.required]],
      state: ['',[Validators.required]],
      qualification: ['',[Validators.required]],
      yearOfCompletion: ['',[Validators.required]],
      
   }); 
  
  }

  ngOnInit(): void {
  }

  Register() :  void{
    if(this.validateForm())
    console.log("clicked register");
    console.log(this.Registerform.value);
    console.log(this.Registerform.value.dateOfBirth)

    this.service.RegisterUser((this.Registerform.value)).subscribe((data)=>{
      console.log(data);
      if(data.status=="Y"){
        console.log("user registerred");
        this.router.navigateByUrl("/login");
        alert("Registration successful. Please login");
      }

      else{
        alert("registration unsuccessful. please register again");
      }
    })
    
  }

  validateForm(){

		//this.regForm.dateOfBirth = this.dateString
		//console.log("regForm DOB"+this.this.Registerform.value.dateOfBirth)
		//console.log("Dob :"+this.dateOfBirth)
  	
		if(this.Registerform.value.fullName==null || this.Registerform.value.fullName=="")
		{
			alert("First Name Cannot be blank");
			return false;
		}
		
		
		if(this.Registerform.value.email==null || this.Registerform.value.email=="")
		{
			alert("Email Cannot be blank");
			return false;
		}
		
		if(this.Registerform.value.password==null || this.Registerform.value.password=="")
		{
			alert("Password cannot be blank");
			return false;
		}
		
				
		if(this.Registerform.value.state=="")
		{
			alert("Please select the state");
			return false;
		}
		if(this.Registerform.value.city=="")
		{
			alert("Please select the city");
			return false;
    }
    if(this.Registerform.value.dateOfBirth==" " ||this.Registerform.value.dateOfBirth==null)
		{
			alert("Please select the Date of birth");
			return false;
    }
	
		return true;
		
	
  }

}
