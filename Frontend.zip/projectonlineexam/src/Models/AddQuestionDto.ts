import { QuestionDetailsDto } from "../../../src/app/QuestionDetailsDto";

export class AddQuestionDto extends QuestionDetailsDto  {
	

    answer : string;
}