export interface Admin {
    adminEmail: string,
    Password: string
    status:string;
}