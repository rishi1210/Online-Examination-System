export class Message {

	status: String;
    msg: String;

}