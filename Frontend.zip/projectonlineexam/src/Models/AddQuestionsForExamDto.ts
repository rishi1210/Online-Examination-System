import { AddQuestionDto } from "./AddQuestionDto";
import { ExamInformationDto } from "../../../src/app/ExamInformationDto";

export class AddquestionsForExamDto extends ExamInformationDto {

    questionsList : AddQuestionDto[];

}