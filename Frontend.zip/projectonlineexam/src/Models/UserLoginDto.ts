export class UserLoginDto {
	
    userEmail : string;
    password : string;
}