export interface UserLoginReceive {
    userId:number,
    status:string
}