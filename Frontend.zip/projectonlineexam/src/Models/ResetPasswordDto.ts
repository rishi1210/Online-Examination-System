export class ResetPasswordDto {

	email: string;
    newPassword	: string;

}