export interface User {
    userid: number;
    name: string;
    emailId: string;
    mobile: string;
    state: string,
    city: string,
    dob: string;
    qualification: string;
    yearOfCompletion: string;
    password: string;
} 

