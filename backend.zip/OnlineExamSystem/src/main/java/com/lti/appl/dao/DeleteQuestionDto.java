package com.lti.appl.dao;

public class DeleteQuestionDto extends ExamInformationDto {

	
	private int questionId;
	
	
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	
}
