package com.lti.appl.exception;

public class OnlineExamException extends Exception{
	
	public OnlineExamException() {
		super();
	}
	public OnlineExamException(String msg) {
		super(msg);
	}

}
